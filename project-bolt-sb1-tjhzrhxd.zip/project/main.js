import './style.css'

// ===== Navbar scroll effect =====
const navbar = document.getElementById('navbar')

window.addEventListener('scroll', () => {
  if (window.scrollY > 60) {
    navbar.classList.add('scrolled')
  } else {
    navbar.classList.remove('scrolled')
  }
})

// ===== Mobile menu toggle =====
const navToggle = document.getElementById('nav-toggle')
const navLinks = document.getElementById('nav-links')

navToggle.addEventListener('click', () => {
  navToggle.classList.toggle('open')
  navLinks.classList.toggle('open')
})

navLinks.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    navToggle.classList.remove('open')
    navLinks.classList.remove('open')
  })
})

// ===== Fade-in animation on scroll =====
const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible')
        observer.unobserve(entry.target)
      }
    })
  },
  { threshold: 0.1 }
)

document
  .querySelectorAll('.energy-card, .advantage-item, .tip-item, .stat-card, .intro-text')
  .forEach((el) => {
    el.classList.add('fade-in')
    observer.observe(el)
  })

// ===== Barra de Acessibilidade =====
const accessBar = document.getElementById('accessibility-bar')
const accessFab = document.getElementById('access-fab')
const btnAccessClose = document.getElementById('btn-access-close')

accessFab.addEventListener('click', () => {
  accessBar.classList.add('open')
  accessFab.classList.add('hidden')
})

btnAccessClose.addEventListener('click', () => {
  accessBar.classList.remove('open')
  accessFab.classList.remove('hidden')
})

// ===== Controle de tamanho de fonte =====
const fontSizes = ['', 'text-size-1', 'text-size-2', 'text-size-3', 'text-size-4']
let currentFontSize = 0

const btnFontIncrease = document.getElementById('btn-font-increase')
const btnFontDecrease = document.getElementById('btn-font-decrease')
const btnFontReset = document.getElementById('btn-font-reset')

function updateFontSize() {
  fontSizes.forEach((cls) => {
    if (cls) document.body.classList.remove(cls)
  })
  if (currentFontSize > 0) {
    document.body.classList.add(fontSizes[currentFontSize])
  }
}

btnFontIncrease.addEventListener('click', () => {
  if (currentFontSize < fontSizes.length - 1) {
    currentFontSize++
    updateFontSize()
  }
})

btnFontDecrease.addEventListener('click', () => {
  if (currentFontSize > 0) {
    currentFontSize--
    updateFontSize()
  }
})

btnFontReset.addEventListener('click', () => {
  currentFontSize = 0
  updateFontSize()
})

// ===== Alto contraste =====
const btnContrast = document.getElementById('btn-contrast')

btnContrast.addEventListener('click', () => {
  const isActive = document.body.classList.toggle('high-contrast')
  btnContrast.setAttribute('aria-pressed', String(isActive))
})

// ===== Modo sem cores (escala de cinza) =====
const btnGrayscale = document.getElementById('btn-grayscale')

btnGrayscale.addEventListener('click', () => {
  const isActive = document.body.classList.toggle('grayscale')
  btnGrayscale.setAttribute('aria-pressed', String(isActive))
})

// ===== Leitura em voz alta (Web Speech API) =====
const btnRead = document.getElementById('btn-read')
let isReading = false
let currentUtterance = null

btnRead.addEventListener('click', () => {
  if (isReading) {
    window.speechSynthesis.cancel()
    stopReading()
    return
  }

  if (!('speechSynthesis' in window)) {
    alert('Seu navegador não suporta leitura em voz alta.')
    return
  }

  const sections = document.querySelectorAll('section, header.hero, footer')
  let fullText = ''
  sections.forEach((section) => {
    const heading = section.querySelector('h1, h2, h3')
    const paragraphs = section.querySelectorAll('p')
    if (heading) fullText += heading.textContent + '. '
    paragraphs.forEach((p) => {
      fullText += p.textContent + ' '
    })
  })

  currentUtterance = new SpeechSynthesisUtterance(fullText)
  currentUtterance.lang = 'pt-BR'
  currentUtterance.rate = 1
  currentUtterance.onend = stopReading
  currentUtterance.onerror = stopReading

  window.speechSynthesis.speak(currentUtterance)
  isReading = true
  btnRead.setAttribute('aria-pressed', 'true')
  btnRead.innerHTML = '<span aria-hidden="true">&#9209;</span> Parar'
})

function stopReading() {
  isReading = false
  btnRead.setAttribute('aria-pressed', 'false')
  btnRead.innerHTML = '<span aria-hidden="true">&#128266;</span> Ler'
}

// Parar leitura se a página for fechada
window.addEventListener('beforeunload', () => {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel()
  }
})

// ===== Fechar menu mobile com tecla Escape =====
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    navToggle.classList.remove('open')
    navLinks.classList.remove('open')
    if (isReading) {
      window.speechSynthesis.cancel()
      stopReading()
    }
  }
})

// ===== Jogo da Memória =====
const memoryEmojis = [
  { emoji: '\u2600\uFE0F', name: 'Solar' },
  { emoji: '\uD83C\uDFD0', name: 'Eólica' },
  { emoji: '\uD83D\uDCA7', name: 'Hidrelétrica' },
  { emoji: '\uD83C\uDF3F', name: 'Biomassa' },
  { emoji: '\uD83C\uDF0B', name: 'Geotérmica' },
  { emoji: '\uD83C\uDF31', name: 'Renovável' },
]

const memoryGrid = document.getElementById('memory-grid')
const memoryMoves = document.getElementById('memory-moves')
const memoryPairs = document.getElementById('memory-pairs')
const memoryTimer = document.getElementById('memory-timer')
const memoryResult = document.getElementById('memory-result')
const memoryResultText = document.getElementById('memory-result-text')
const memoryRestartBtn = document.getElementById('memory-restart')
const memoryRestart2Btn = document.getElementById('memory-restart-2')

let memoryCards = []
let memoryFlippedCards = []
let memoryMatchedPairs = 0
let memoryMoveCount = 0
let memoryCanFlip = true
let memoryTimerInterval = null
let memorySeconds = 0

function shuffleArray(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[arr[i], arr[j]] = [arr[j], arr[i]]
  }
  return arr
}

function startMemoryTimer() {
  memorySeconds = 0
  memoryTimer.textContent = '0s'
  if (memoryTimerInterval) clearInterval(memoryTimerInterval)
  memoryTimerInterval = setInterval(() => {
    memorySeconds++
    memoryTimer.textContent = memorySeconds + 's'
  }, 1000)
}

function stopMemoryTimer() {
  if (memoryTimerInterval) {
    clearInterval(memoryTimerInterval)
    memoryTimerInterval = null
  }
}

function initMemoryGame() {
  memoryCards = []
  memoryFlippedCards = []
  memoryMatchedPairs = 0
  memoryMoveCount = 0
  memoryCanFlip = true
  memorySeconds = 0
  stopMemoryTimer()

  memoryMoves.textContent = '0'
  memoryPairs.textContent = '0 / 6'
  memoryTimer.textContent = '0s'
  memoryResult.style.display = 'none'

  const pairs = [...memoryEmojis, ...memoryEmojis]
  shuffleArray(pairs)

  memoryGrid.innerHTML = ''
  pairs.forEach((item, index) => {
    const card = document.createElement('div')
    card.className = 'memory-card'
    card.setAttribute('role', 'gridcell')
    card.setAttribute('tabindex', '0')
    card.setAttribute('aria-label', 'Carta virada, clique para revelar')
    card.dataset.name = item.name
    card.dataset.index = index

    card.innerHTML = `
      <div class="memory-card-inner">
        <div class="memory-card-front"></div>
        <div class="memory-card-back">${item.emoji}</div>
      </div>
    `

    card.addEventListener('click', () => flipMemoryCard(card))
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault()
        flipMemoryCard(card)
      }
    })

    memoryGrid.appendChild(card)
    memoryCards.push(card)
  })
}

function flipMemoryCard(card) {
  if (!memoryCanFlip) return
  if (card.classList.contains('flipped') || card.classList.contains('matched')) return

  if (memoryMoveCount === 0 && memorySeconds === 0) {
    startMemoryTimer()
  }

  card.classList.add('flipped')
  card.setAttribute('aria-label', 'Carta: ' + card.dataset.name)
  memoryFlippedCards.push(card)

  if (memoryFlippedCards.length === 2) {
    memoryCanFlip = false
    memoryMoveCount++
    memoryMoves.textContent = memoryMoveCount

    const [card1, card2] = memoryFlippedCards
    if (card1.dataset.name === card2.dataset.name) {
      card1.classList.add('matched')
      card2.classList.add('matched')
      memoryMatchedPairs++
      memoryPairs.textContent = memoryMatchedPairs + ' / 6'
      memoryFlippedCards = []
      memoryCanFlip = true

      if (memoryMatchedPairs === 6) {
        endMemoryGame()
      }
    } else {
      setTimeout(() => {
        card1.classList.remove('flipped')
        card2.classList.remove('flipped')
        card1.setAttribute('aria-label', 'Carta virada, clique para revelar')
        card2.setAttribute('aria-label', 'Carta virada, clique para revelar')
        memoryFlippedCards = []
        memoryCanFlip = true
      }, 900)
    }
  }
}

function endMemoryGame() {
  stopMemoryTimer()
  memoryResult.style.display = 'block'

  let message = ''
  if (memoryMoveCount <= 8) {
    message = 'Incrível! Você completou em apenas ' + memoryMoveCount + ' jogadas e ' + memorySeconds + ' segundos. Você tem uma memória excelente!'
  } else if (memoryMoveCount <= 12) {
    message = 'Muito bem! Você completou em ' + memoryMoveCount + ' jogadas e ' + memorySeconds + ' segundos. Continue praticando!'
  } else {
    message = 'Parabéns! Você completou em ' + memoryMoveCount + ' jogadas e ' + memorySeconds + ' segundos. Tente de novo para melhorar seu tempo!'
  }
  memoryResultText.textContent = message
}

memoryRestartBtn.addEventListener('click', initMemoryGame)
memoryRestart2Btn.addEventListener('click', initMemoryGame)

initMemoryGame()

// ===== Quiz =====
const quizQuestions = [
  {
    question: 'O que é energia sustentável?',
    options: [
      'Energia obtida de fontes que se renovam e não se esgotam',
      'Energia obtida apenas de usinas nucleares',
      'Energia que vem do petróleo e do carvão',
      'Energia que só existe em países desenvolvidos',
    ],
    correct: 0,
    explanation: 'A energia sustentável vem de fontes que se renovam naturalmente, como sol, vento e água, e não se esgotam.',
  },
  {
    question: 'Qual destas é uma fonte de energia renovável?',
    options: [
      'Carvão mineral',
      'Petróleo',
      'Energia solar',
      'Gás natural',
    ],
    correct: 2,
    explanation: 'A energia solar usa a luz e o calor do sol, uma fonte que nunca se esgota, para gerar eletricidade.',
  },
  {
    question: 'Como a energia eólica gera eletricidade?',
    options: [
      'Aproveitando o calor do interior da Terra',
      'Usando a força do vento para girar turbinas',
      'Queimando matéria orgânica',
      'Aproveitando a força da água dos rios',
    ],
    correct: 1,
    explanation: 'A energia eólica usa a força do vento para girar grandes turbinas, que então geram eletricidade.',
  },
  {
    question: 'Qual é a principal fonte de energia elétrica no Brasil?',
    options: [
      'Energia solar',
      'Energia nuclear',
      'Energia hidrelétrica',
      'Energia geotérmica',
    ],
    correct: 2,
    explanation: 'No Brasil, a energia hidrelétrica é a principal fonte, pois o país tem muitos rios que alimentam as usinas.',
  },
  {
    question: 'O que é biomassa?',
    options: [
      'Um tipo de painel solar',
      'Matéria orgânica usada para produzir energia',
      'Um gás poluente liberado por fábricas',
      'Um tipo de turbina eólica',
    ],
    correct: 1,
    explanation: 'A biomassa é matéria orgânica (restos de plantas, madeira, lixo orgânico) que pode ser transformada em energia.',
  },
  {
    question: 'Qual destas atitudes ajuda a economizar energia no dia a dia?',
    options: [
      'Deixar as luzes acesas o dia todo',
      'Manter aparelhos na tomada mesmo sem usar',
      'Usar lâmpadas de LED e desligar ao sair do cômodo',
      'Tomar banhos muito longos de água quente',
    ],
    correct: 2,
    explanation: 'Lâmpadas de LED gastam menos energia, e desligar as luzes ao sair evita desperdício.',
  },
]

let quizCurrentIndex = 0
let quizScore = 0
let quizAnswered = false

const quizQuestionText = document.getElementById('quiz-question-text')
const quizQuestionNumber = document.getElementById('quiz-question-number')
const quizOptionsContainer = document.getElementById('quiz-options')
const quizFeedback = document.getElementById('quiz-feedback')
const quizBtnNext = document.getElementById('quiz-btn-next')
const quizBtnRestart = document.getElementById('quiz-btn-restart')
const quizProgressFill = document.getElementById('quiz-progress-fill')
const quizProgressText = document.getElementById('quiz-progress-text')
const quizQuestionArea = document.getElementById('quiz-question-area')
const quizResult = document.getElementById('quiz-result')
const quizResultIcon = document.getElementById('quiz-result-icon')
const quizResultTitle = document.getElementById('quiz-result-title')
const quizResultScore = document.getElementById('quiz-result-score')
const quizResultMessage = document.getElementById('quiz-result-message')

function renderQuizQuestion() {
  const q = quizQuestions[quizCurrentIndex]
  quizAnswered = false

  quizQuestionText.textContent = q.question
  quizQuestionNumber.textContent = quizCurrentIndex + 1
  quizFeedback.classList.remove('show', 'correct', 'incorrect')
  quizFeedback.textContent = ''
  quizBtnNext.disabled = true

  const progress = (quizCurrentIndex / quizQuestions.length) * 100
  quizProgressFill.style.width = progress + '%'
  quizProgressText.textContent = `Pergunta ${quizCurrentIndex + 1} de ${quizQuestions.length}`

  const letters = ['A', 'B', 'C', 'D']
  quizOptionsContainer.innerHTML = ''
  q.options.forEach((option, i) => {
    const btn = document.createElement('button')
    btn.className = 'quiz-option'
    btn.innerHTML = `<span class="quiz-option-letter">${letters[i]}</span><span class="quiz-option-text">${option}</span>`
    btn.addEventListener('click', () => selectQuizAnswer(i))
    quizOptionsContainer.appendChild(btn)
  })
}

function selectQuizAnswer(selectedIndex) {
  if (quizAnswered) return
  quizAnswered = true

  const q = quizQuestions[quizCurrentIndex]
  const options = quizOptionsContainer.querySelectorAll('.quiz-option')
  options.forEach((opt) => opt.classList.add('disabled'))

  if (selectedIndex === q.correct) {
    options[selectedIndex].classList.add('correct')
    quizScore++
    quizFeedback.textContent = 'Resposta correta! ' + q.explanation
    quizFeedback.classList.add('show', 'correct')
  } else {
    options[selectedIndex].classList.add('incorrect')
    options[q.correct].classList.add('correct')
    quizFeedback.textContent = 'Resposta incorreta. ' + q.explanation
    quizFeedback.classList.add('show', 'incorrect')
  }

  quizBtnNext.disabled = false
}

quizBtnNext.addEventListener('click', () => {
  quizCurrentIndex++
  if (quizCurrentIndex < quizQuestions.length) {
    renderQuizQuestion()
  } else {
    showQuizResult()
  }
})

function showQuizResult() {
  quizProgressFill.style.width = '100%'
  quizProgressText.textContent = 'Quiz concluído!'
  quizQuestionArea.style.display = 'none'
  quizFeedback.style.display = 'none'
  quizBtnNext.style.display = 'none'
  quizResult.style.display = 'block'
  quizBtnRestart.style.display = 'inline-block'

  const total = quizQuestions.length
  const percentage = Math.round((quizScore / total) * 100)

  if (quizScore === total) {
    quizResultIcon.textContent = '\uD83C\uDFC6'
    quizResultTitle.textContent = 'Perfeito!'
    quizResultMessage.textContent = 'Você acertou todas as perguntas! Parabéns, você entende tudo sobre energia sustentável!'
  } else if (quizScore >= total * 0.6) {
    quizResultIcon.textContent = '\uD83C\uDF31'
    quizResultTitle.textContent = 'Muito bem!'
    quizResultMessage.textContent = 'Você aprendeu bastante sobre energia sustentável! Revise o conteúdo e tente de novo para acertar tudo.'
  } else {
    quizResultIcon.textContent = '\uD83D\uDCDA'
    quizResultTitle.textContent = 'Continue estudando!'
    quizResultMessage.textContent = 'Você ainda pode aprender mais sobre energia sustentável. Reveja o conteúdo do site e refaça o quiz!'
  }

  quizResultScore.textContent = `${quizScore} de ${total} acertos (${percentage}%)`
}

quizBtnRestart.addEventListener('click', () => {
  quizCurrentIndex = 0
  quizScore = 0
  quizResult.style.display = 'none'
  quizBtnRestart.style.display = 'none'
  quizQuestionArea.style.display = 'block'
  quizBtnNext.style.display = 'inline-block'
  quizBtnNext.disabled = true
  renderQuizQuestion()
})

renderQuizQuestion()
